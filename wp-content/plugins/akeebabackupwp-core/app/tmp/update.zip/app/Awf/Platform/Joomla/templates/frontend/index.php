<?php
	include __DIR__ . '/php/head.php';
	echo $this->getBuffer();
?>